% Trabalho 4. 
% Pedro V D S Matias (pvsm@icomp.ufam.edu.br), 30-05-2019 12:29 
%-------------------------------------------------------------------------
close all,clear all,clc;


% Rede Neural arquitetura 1-S-1
% 1) Gerar 50 pontos igualmente espaçados entre -2 e 2;
p = linspace(-2,2,50)';

% 2) Utilizar os pontos ímpares para treinamento e os pares para teste;
p_tr = []; p_tt = []; % vetor pontos de treinamento e teste
for i=1:length(p)
    if mod(p(i),2) ~= 0 % impares
        p_tr(end+1,1) = p(i);
    else
        p_tt(end+1,1) = p(i);
    end
end
% 3) Realizar o treinamento e determinar a menor quantidade de neurônios na 
%   camada intermediária, n, para a qual a função é aproximada com razoável precisão;
%f = 1 + cos(p*6*pi/4);
% W[S,R], Matriz de pesos e b[S,1] - vetor de polarização, sendo R = 1
R = 1; S1 = 6; S2 = 1;
W1 = randn(S1,R);    b1 = randn(S1,1);
W2 = randn(S2,S1);   b2 = randn(S2,1);
save('W1_inicial.txt','W1','-ascii'); % Para salvar os dados
save('W2_inicial.txt','W2','-ascii');
save('b1_inicial.txt','b1','-ascii');
save('b2_inicial.txt','b2','-ascii');
epoca_tr = 12000;
E = zeros(1,epoca_tr);


for k = 1:epoca_tr 
    disp(k);
    %x = randsample(p_tr,length(p_tr));
    x = p_tr;
    for i = 1:length(p_tr)
        
     % Forward Propagation
        a0 = x(i);
        t  = 1 + cos(a0*6*pi/4);
        % Saída da primeira camada oculta
        n1 = W1*a0 + b1;
        a1 = logsig(n1);
        
        % Saída da segunda camada
        n2 = W2*a1 + b2;
        a2 = purelin(n2);
        
        % O erro será
        e = (t - a2);
        
     % Backward Propagation
        % derivadas das funções de transferência e sensiblidade
        F2 = diag(dpurelin(n2,a2));
        s2 = -2 * F2 * e;
        F1 = diag(dlogsig(n1,a1));
        s1 = F1 * W2' * s2;
        
        % Para simplificar, usaremos uma taxa de aprendizado 0,1
        alpha = 0.1;
        W2 = W2 - alpha .* s2 * a1';
        b2 = b2 -alpha .* s2;
        
        W1 = W1 - alpha .* s1 * a0';
        b1 = b1 - alpha .* s1;
        
    end
end
% Teste da rede
g = [];
for i = 1: length(p)
    % Saída da primeira camada oculta
    a0 = p(i);
    n1 = W1*a0 + b1;
    a1 = logsig(n1);
    % Saída da segunda camada
    n2 = W2*a1 + b2;
    a2 = purelin(n2);   
    g(end+1,1) = a2;
end

%figure;
y = 1 + cos(p*6*pi/4);
plot(p, y)

title('Rede Neural 1-6-1')

hold on

plot(p,g)
scatter(p,g)
hold off
